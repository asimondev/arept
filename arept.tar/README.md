# AREPT
AREPT Python scripts.

This *README* describes the usage of AREPT Python scripts to get performance reports from Oracle database. The results are written into text and HTML files. The tool uses SQL*Plus to select the data  


