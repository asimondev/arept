#!/usr/bin/python3
#
# Author: Andrej Simon, Oracle ACS Germany
#
# This is the main script to start arept. Use this file with Python3.
#

from my_mods.main import start_arept

if __name__ == '__main__':
    start_arept()
